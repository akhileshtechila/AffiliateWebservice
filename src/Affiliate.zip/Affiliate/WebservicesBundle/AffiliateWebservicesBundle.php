<?php

namespace Affiliate\WebservicesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AffiliateWebservicesBundle extends Bundle
{
}
