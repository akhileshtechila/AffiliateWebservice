<?php

namespace Affiliate\AffiliateManagementBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * AffiliatePayReq
 */
class AffiliatePayReq
{
      
     /**
     * @ORM\PrePersist
     */

    public function setCreatedOnValue() {

        $this->createdDate = new \DateTime();
        $this->updatedDate = new \DateTime();
    }

    /**
     * @ORM\PreUpdate
     */
    public function setUpdatedOnValue() {

        $this->updatedDate = new \DateTime();
    }
    
    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $requestedAmt;

    /**
     * @var \DateTime
     */
    private $requestedDate;

    /**
     * @var string
     */
    private $description;

    /**
     * @var string
     */
    private $reqStatus;

    /**
     * @var \DateTime
     */
    private $createdDate;

    /**
     * @var \DateTime
     */
    private $updatedDate;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set requestedAmt
     *
     * @param string $requestedAmt
     * @return AffiliatePayReq
     */
    public function setRequestedAmt($requestedAmt)
    {
        $this->requestedAmt = $requestedAmt;

        return $this;
    }

    /**
     * Get requestedAmt
     *
     * @return string 
     */
    public function getRequestedAmt()
    {
        return $this->requestedAmt;
    }

    /**
     * Set requestedDate
     *
     * @param \DateTime $requestedDate
     * @return AffiliatePayReq
     */
    public function setRequestedDate($requestedDate)
    {
        $this->requestedDate = $requestedDate;

        return $this;
    }

    /**
     * Get requestedDate
     *
     * @return \DateTime 
     */
    public function getRequestedDate()
    {
        return $this->requestedDate;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return AffiliatePayReq
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set reqStatus
     *
     * @param string $reqStatus
     * @return AffiliatePayReq
     */
    public function setReqStatus($reqStatus)
    {
        $this->reqStatus = $reqStatus;

        return $this;
    }

    /**
     * Get reqStatus
     *
     * @return string 
     */
    public function getReqStatus()
    {
        return $this->reqStatus;
    }

    /**
     * Set createdDate
     *
     * @param \DateTime $createdDate
     * @return AffiliatePayReq
     */
    public function setCreatedDate($createdDate)
    {
        $this->createdDate = $createdDate;

        return $this;
    }

    /**
     * Get createdDate
     *
     * @return \DateTime 
     */
    public function getCreatedDate()
    {
        return $this->createdDate;
    }

    /**
     * Set updatedDate
     *
     * @param \DateTime $updatedDate
     * @return AffiliatePayReq
     */
    public function setUpdatedDate($updatedDate)
    {
        $this->updatedDate = $updatedDate;

        return $this;
    }

    /**
     * Get updatedDate
     *
     * @return \DateTime 
     */
    public function getUpdatedDate()
    {
        return $this->updatedDate;
    }
}
