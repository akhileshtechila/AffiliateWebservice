<?php

namespace Affiliate\AffiliateManagementBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AffiliateAffiliateManagementBundle extends Bundle
{
}
